# 7 landings · 7 esqueletos

Siete landings de negocios de barrio, cada una con un esqueleto que sale de algo del propio negocio. Los negocios son de ejemplo (inventados) y las fotos están generadas con IA: cámbialas por las tuyas.

| Archivo | Negocio de ejemplo | De dónde sale el esqueleto |
|---|---|---|
| `landings/01-cafeteria-grano-norte.html` | Cafetería | El aro que deja la taza: hero en círculo y la carta como una rueda |
| `landings/02-panaderia-la-tahona.html` | Panadería | El corte del pan: cada sección entra en diagonal |
| `landings/03-barberia-navaja.html` | Barbería | Las franjas del poste: un servicio por columna |
| `landings/04-veterinaria-huella.html` | Veterinaria | La huella: la almohadilla es la foto y los cuatro dedos, los servicios |
| `landings/05-pasteleria-capas.html` | Pastelería | La torta: cada sección es una capa con su borde de crema |
| `landings/06-floreria-tallo.html` | Florería | El tallo: cada servicio sale de la línea como una hoja |
| `landings/07-cevicheria-limon-y-sal.html` | Cevichería | El limón: ocho gajos, ocho platos, el ceviche al centro |

## Cómo verlas
- Abre `index.html` (la galería) o cualquier archivo de `landings/` en Chrome. Están pensadas para escritorio (1440 px de ancho).
- Agrega `?wire` al final de la dirección para ver su esqueleto en gris (lo hace `landings/wire.js` sobre la misma página).

## Cómo hacer la tuya con Claude o Codex
Abre la carpeta en tu agente y pega el prompt de `PROMPT.md`. La idea no es copiar el esqueleto de otro negocio: es encontrar el de tu negocio.

Hecho por Rayyan · rayyan.pe
