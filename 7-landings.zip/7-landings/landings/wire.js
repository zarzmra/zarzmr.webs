/* ?wire convierte la landing en su wireframe gris, sin tocar el layout: el esqueleto es exactamente la misma página.
   Fondos → gris por luminancia · textos → barras redondeadas por línea · fotos → bloque con ícono · SVG → gris. */
(function () {
  if (!/[?&]wire\b/.test(location.search)) return;
  const lum = (c) => { const m = c.match(/[\d.]+/g); if (!m) return null; const [r, g, b, a = 1] = m.map(Number); if (a < 0.05) return null; return (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255; };
  const gray = (l) => { const v = Math.round(36 + l * 196); return `rgb(${v},${v},${v + 3})`; };
  const ICON = "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 48 40'%3E%3Cpath d='M4 34 L17 18 L26 28 L33 21 L44 34 Z' fill='%23e9ebee'/%3E%3Ccircle cx='34' cy='10' r='5' fill='%23e9ebee'/%3E%3C/svg%3E\")";
  const run = () => {
    document.documentElement.classList.add("wire");
    const all = [...document.querySelectorAll("body, body *")];
    // 1 · fondos y bordes a gris
    for (const el of all) {
      const cs = getComputedStyle(el);
      if (el.matches(".ph, img") || /url\(/.test(cs.backgroundImage)) continue;
      const l = lum(cs.backgroundColor); if (l !== null) el.style.setProperty("background-color", gray(l), "important");
      if (cs.backgroundImage !== "none") el.style.setProperty("background-image", "none", "important");
      const bl = lum(cs.borderTopColor); if (bl !== null && parseFloat(cs.borderTopWidth) > 0) el.style.setProperty("border-color", gray(bl), "important");
      el.style.setProperty("box-shadow", "none", "important"); el.style.setProperty("text-shadow", "none", "important");
    }
    // 2 · fotos: bloque gris con el ícono de imagen
    for (const el of document.querySelectorAll(".ph, img")) {
      const box = el.tagName === "IMG" ? el.parentElement.classList.contains("ph") ? null : el : el;
      if (el.tagName === "IMG") el.style.setProperty("opacity", "0", "important");
      if (box) { box.style.setProperty("background", `#43464c ${ICON} center/56px no-repeat`, "important"); }
      if (el.classList.contains("ph")) el.style.setProperty("background", `#43464c ${ICON} center/56px no-repeat`, "important");
    }
    // 3 · SVG decorativo a gris
    for (const s of document.querySelectorAll("svg *")) {
      const cs = getComputedStyle(s);
      if (cs.fill && cs.fill !== "none") { const l = lum(cs.fill); if (l !== null) s.style.setProperty("fill", gray(Math.min(.85, l)), "important"); }
      if (cs.stroke && cs.stroke !== "none") { const l = lum(cs.stroke); if (l !== null) s.style.setProperty("stroke", gray(Math.min(.85, l)), "important"); }
    }
    // 4 · texto → barras (color según el fondo de debajo)
    const bgOf = (el) => { for (let e = el; e; e = e.parentElement) { const l = lum(getComputedStyle(e).backgroundColor); if (l !== null) return l; } return 1; };
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, { acceptNode: (n) => n.nodeValue.trim() && !n.parentElement.closest("svg, script, style") ? 1 : 2 });
    const nodes = []; while (walker.nextNode()) nodes.push(walker.currentNode);
    for (const n of nodes) {
      const sp = document.createElement("span"); sp.className = "wt"; n.parentNode.insertBefore(sp, n); sp.appendChild(n);
      const l = bgOf(sp.parentElement); sp.style.setProperty("--wt", l < .45 ? "#6f737a" : "#b9bdc4");
    }
  };
  const st = document.createElement("style");
  st.textContent = `html.wire *{color:transparent!important;-webkit-text-stroke:0!important;caret-color:transparent}
  html.wire *::before,html.wire *::after{background-color:#8b8f96!important;border-color:#9a9ea5!important;background-image:none!important;box-shadow:none!important}
  html.wire .wt{background:var(--wt);border-radius:999px;-webkit-box-decoration-break:clone;box-decoration-break:clone}`;
  document.head.appendChild(st);
  (document.fonts ? document.fonts.ready : Promise.resolve()).then(() => setTimeout(run, 50));
})();
