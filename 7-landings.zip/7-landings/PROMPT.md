# Prompt para tu agente (Claude Code o Codex)

Pega esto en la carpeta de este pack y cambia lo que está entre corchetes:

```
Mira las 7 landings de la carpeta landings/ y lee el LEEME.md: cada una tiene un esqueleto que sale de algo del propio negocio (el aro de la taza, el corte del pan, la huella…).

Ahora hazme una landing para mi negocio: [nombre], [qué vendes], [ciudad]. Mi Instagram es [@usuario] y mis colores son [colores o "tómalos de mi logo"].

1. Antes de diseñar, dame 5 cosas reales y repetidas de mi negocio (un objeto, una forma, un gesto, algo de mi local o de mi logo) y propón 2 esqueletos distintos que salgan de una de ellas. Espera a que elija.
2. Constrúyela en un solo HTML, como las del pack: 1440 px de escritorio y que también funcione en celular (390 px).
3. Usa mis fotos reales (te las paso) y mis datos reales: horarios, precios y WhatsApp. No inventes reseñas, cifras ni datos.
4. El pedido o la reserva termina en mi WhatsApp.
5. Agrega wire.js para que con ?wire se vea su esqueleto en gris.
```

¿Prefieres que te la haga yo? rayyan.pe/web
